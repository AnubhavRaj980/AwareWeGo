export const prices = [
    {
        _id: 0,
        name: "Any",
        array: []
    },
    {
        _id: 1,
        name: "₹0 to ₹99",
        array: [0, 99]
    },
    {
        _id: 2,
        name: "₹100 to ₹499",
        array: [100, 499]
    },
    {
        _id: 3,
        name: "₹500 to ₹999",
        array: [500, 999]
    },
    {
        _id: 4,
        name: "₹30 to ₹39",
        array: [999, 1499]
    },
    {
        _id: 5,
        name: "More than ₹1500",
        array: [1500, 5000]
    }
];
